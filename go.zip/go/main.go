package main

import (
    "encoding/json"
    "net/http"
    "strconv"
    "sync"

    "github.com/gorilla/mux"
    "github.com/rs/cors"
)

type Task struct {
    ID   int    `json:"id"`
    Name string `json:"name"`
}

var (
    tasks  []Task
    nextID int = 1
    mu     sync.Mutex
)

func getTasks(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Content-Type", "application/json")
    mu.Lock()
    defer mu.Unlock()
    json.NewEncoder(w).Encode(tasks)
}

func addTask(w http.ResponseWriter, r *http.Request) {
    var task Task
    if err := json.NewDecoder(r.Body).Decode(&task); err != nil {
        http.Error(w, "Invalid input", http.StatusBadRequest)
        return
    }

    mu.Lock()
    defer mu.Unlock()
    task.ID = nextID
    nextID++
    tasks = append(tasks, task)
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(task)
}

func updateTask(w http.ResponseWriter, r *http.Request) {
    vars := mux.Vars(r)
    id, err := strconv.Atoi(vars["id"])
    if err != nil {
        http.Error(w, "Invalid task ID", http.StatusBadRequest)
        return
    }

    var updatedTask Task
    if err := json.NewDecoder(r.Body).Decode(&updatedTask); err != nil {
        http.Error(w, "Invalid input", http.StatusBadRequest)
        return
    }

    mu.Lock()
    defer mu.Unlock()
    for i, task := range tasks {
        if task.ID == id {
            tasks[i].Name = updatedTask.Name
            w.Header().Set("Content-Type", "application/json")
            json.NewEncoder(w).Encode(tasks[i])
            return
        }
    }

    http.Error(w, "Task not found", http.StatusNotFound)
}

func deleteTask(w http.ResponseWriter, r *http.Request) {
    vars := mux.Vars(r)
    id, err := strconv.Atoi(vars["id"])
    if err != nil {
        http.Error(w, "Invalid task ID", http.StatusBadRequest)
        return
    }

    mu.Lock()
    defer mu.Unlock()
    for i, task := range tasks {
        if task.ID == id {
            tasks = append(tasks[:i], tasks[i+1:]...)
            w.WriteHeader(http.StatusNoContent)
            return
        }
    }

    http.Error(w, "Task not found", http.StatusNotFound)
}

func main() {
    r := mux.NewRouter()

    r.HandleFunc("/tasks", getTasks).Methods("GET")
    r.HandleFunc("/tasks", addTask).Methods("POST")
    r.HandleFunc("/tasks/{id}", updateTask).Methods("PUT")
    r.HandleFunc("/tasks/{id}", deleteTask).Methods("DELETE")

    handler := cors.AllowAll().Handler(r)
    http.ListenAndServe(":8080", handler)
}
