import React, { useState, useEffect } from "react";
import axios from "axios";

const App = () => {
  const [tasks, setTasks] = useState([]); // Store tasks
  const [newTask, setNewTask] = useState(""); // Input for new task
  const [editTask, setEditTask] = useState(null); // Task currently being edited
  const [loading, setLoading] = useState(false); // Loader state

  // Fetch tasks on component mount
  useEffect(() => {
    fetchTasks();
  }, []);

  // Fetch tasks from backend
  const fetchTasks = async () => {
    try {
      setLoading(true);
      const response = await axios.get("http://localhost:8080/tasks");
      setTasks(response.data || []); // Ensure tasks is always an array
    } catch (error) {
      console.error("Error fetching tasks:", error);
    } finally {
      setLoading(false);
    }
  };

  // Add a new task
  const addTask = async () => {
    if (!newTask.trim()) return; // Ignore empty input
    try {
      const response = await axios.post("http://localhost:8080/tasks", {
        name: newTask.trim(),
      });
      setTasks([...tasks, response.data]);
      setNewTask(""); // Clear input after adding
    } catch (error) {
      console.error("Error adding task:", error);
    }
  };

  // Update an existing task
  const updateTask = async (id) => {
    if (!editTask.name.trim()) return; // Ignore empty input
    try {
      const response = await axios.put(`http://localhost:8080/tasks/${id}`, {
        name: editTask.name.trim(),
      });
      setTasks(
        tasks.map((task) => (task.id === id ? response.data : task))
      );
      setEditTask(null); // Exit edit mode after saving
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  // Delete a task
  const deleteTask = async (id) => {
    try {
      await axios.delete(`http://localhost:8080/tasks/${id}`);
      setTasks(tasks.filter((task) => task.id !== id));
    } catch (error) {
      console.error("Error deleting task:", error);
    }
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial, sans-serif" }}>
      <h1>Task Manager</h1>

      {/* New Task Input */}
      <div style={{ marginBottom: "20px" }}>
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Add a new task"
          style={{ padding: "10px", width: "70%", marginRight: "10px" }}
        />
        <button
          onClick={addTask}
          style={{
            padding: "10px 20px",
            backgroundColor: "#007BFF",
            color: "#FFF",
            border: "none",
            cursor: "pointer",
          }}
        >
          Add Task
        </button>
      </div>

      {/* Task List */}
      {loading ? (
        <p>Loading tasks...</p>
      ) : (
        <ul style={{ listStyle: "none", padding: 0 }}>
          {(tasks || []).map((task) => (
            <li
              key={task.id}
              style={{
                marginBottom: "10px",
                display: "flex",
                alignItems: "center",
              }}
            >
              {editTask && editTask.id === task.id ? (
                <input
                  type="text"
                  value={editTask.name}
                  onChange={(e) =>
                    setEditTask({ ...editTask, name: e.target.value })
                  }
                  style={{ padding: "5px", marginRight: "10px", flex: 1 }}
                />
              ) : (
                <span style={{ flex: 1 }}>{task.name}</span>
              )}

              {editTask && editTask.id === task.id ? (
                <button
                  onClick={() => updateTask(task.id)}
                  style={{
                    padding: "5px 10px",
                    marginLeft: "10px",
                    backgroundColor: "#28A745",
                    color: "#FFF",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Save
                </button>
              ) : (
                <button
                  onClick={() => setEditTask(task)}
                  style={{
                    padding: "5px 10px",
                    marginLeft: "10px",
                    backgroundColor: "#FFC107",
                    color: "#FFF",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Edit
                </button>
              )}

              <button
                onClick={() => deleteTask(task.id)}
                style={{
                  padding: "5px 10px",
                  marginLeft: "10px",
                  backgroundColor: "#DC3545",
                  color: "#FFF",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default App;
